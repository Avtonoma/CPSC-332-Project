<?php

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    //get data from form post
    $ssn = $_POST['ssn'] ?? '';
    $fname = $_POST['fname'] ?? '';
    $lname = $_POST['lname'] ?? '';
    //validate form
    $isvalid = true;
    if(!is_numeric($ssn) || strlen($ssn) != 9){
        echo "Invalid ssn<br>";        
        $isvalid = false;
    }
    if(!isset($fname) || trim($fname) === ''){
        echo "fname cannot be empty<br>";        
        $isvalid = false;
    }
    if(!isset($lname) || trim($lname) === ''){
        echo "fname cannot be empty<br>";
        $isvalid = false;
    }
    
    //if valid, insert employee
    if($isvalid){
        //configuration
        define("DB_SERVER", "localhost");
        define("DB_USER", "root");
        define("DB_PWD", "");
        define("DB_NAME", "company");
        //database connection
        $mysqli = new mysqli(DB_SERVER, DB_USER, DB_PWD, DB_NAME);
        if($mysqli -> connect_errno) {
            echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
            exit();
        }
        $query = "insert into employee(ssn,fname,lname) values('" . $ssn ."','" . $fname ."','" . $lname ."')" ;
        echo $query;
        $isInserted = $mysqli -> query($query);
        //check update
        if($isInserted) {
            //if success redirect to index
             header("location:index.php");
          } else {
            // UPDATE failed
            echo $mysqli->error();
          }
        
        //free memeory
        $isInserted->free_result();
        //close connection
        if(is_resource($mysqli)){
            $mysqli->close();
        }
    } 
}
?>
<!-- create from -->
<form action='' method='post'>
<div>
        SSN: <input type='text' name='ssn'>
</div>
<div>
        First Name: <input type='text' name='fname'>
</div>
<div>
        Last Name: <input type='text' name='lname'>
</div>
<input type='submit' value='submit'>
</form>

<?php

?>