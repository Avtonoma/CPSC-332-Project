<h3>OOP</h3>


<?php



//get ssn from query string
if(!isset($_GET['ssn'])) {
    header("location:index.php");
}
$ssn = $_GET['ssn'];
//configuration
define("DB_SERVER", "localhost");
define("DB_USER", "root");
define("DB_PWD", "");
define("DB_NAME", "company");
//database connection
$mysqli = new mysqli(DB_SERVER, DB_USER, DB_PWD, DB_NAME);
if($mysqli -> connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
    exit();
}

//if user post update
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    //get data from form post
    $fname = $_POST['fname'] ?? '';
    $lname = $_POST['lname'] ?? '';
    //validate form
    $isvalid = true;
    if(!isset($fname) || trim($fname) === ''){
        echo "fname cannot be empty";        
        $isvalid = false;
    }
    if(!isset($lname) || trim($lname) === ''){
        echo "fname cannot be empty";
        $isvalid = false;
    }
    //update database
    if($isvalid){
        $uquery = "update EMPLOYEE set fname='". $fname ."', lname='" . $lname ."' where ssn='". $ssn ."'" ;
        $isupdated = $mysqli -> query($uquery);
        //check update
        if($isupdated) {
             header("location:index.php");
          } else {
            // UPDATE failed
            echo $mysqli->error();
          }
        //if success redirect to index
    } 
}
//get employee by ssn
$sql = "SELECT * FROM employee WHERE SSN='". $ssn ."'";
//execute query
$result = $mysqli->query($sql);
//validate query
if (!$result) {
    exit("Database query failed.");
}
//display query
$emp = $result->fetch_assoc();
?>


<form action='' method='post'>
<div>
        SSN: <input type='text' name='ssn' value="<?php echo $emp['ssn']; ?>">
</div>
<div>
        First Name: <input type='text' name='fname' value="<?php echo $emp['fname']; ?>">
</div>
<div>
        Last Name: <input type='text' name='lname' value="<?php echo $emp['lname']; ?>">
</div>
<input type='submit' value='submit'>
</form>
<?php
//free memeory
$result->free_result();
//close connection
if(is_resource($mysqli)){
    $mysqli->close();
}
?>