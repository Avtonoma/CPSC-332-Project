<h3>OOP</h3>
<a href="create.php">Create</a>
<br>
<br>
<?php
echo $_SERVER['SERVER_NAME'] ."<br>";
echo $_SERVER['REMOTE_ADDR'] . "<br>";
echo $_SERVER['HTTP_HOST'] . "<br>";

//configuration
define("DB_SERVER", "localhost");
define("DB_USER", "root");
define("DB_PWD", "");
define("DB_NAME", "company");
//database connection
$mysqli = new mysqli(DB_SERVER, DB_USER, DB_PWD, DB_NAME);
if($mysqli -> connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
    exit();
}
//query
$sql = "SELECT ssn, fname, lname FROM employee WHERE SSN LIKE '1%' ORDER BY ssn desc";
//execute query
$result = $mysqli->query($sql);
//validate query
if (!$result) {
    exit("Database query failed.");
}

//display query
?>

<table class="list">
  	<tr>
        <th>SSN</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Actions</th>
  	</tr>
    <?php while($emp = $result->fetch_assoc()) { ?>
        <tr>
          <td><?php echo $emp['ssn']; ?></td>
          <td><?php echo $emp['fname']; ?></td>
          <td><?php echo $emp['lname']; ?></td>
          <td><?php echo ("<a href='edit.php?ssn=" .$emp['ssn']. "'>Edit</a>") ?></td>
    	</tr>
    <?php } ?>
</table>

<?php
//free memeory
$result->free_result();
//close connection
if(is_resource($mysqli)){
    $mysqli->close();
}
?>